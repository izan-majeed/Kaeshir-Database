from kashmiri.kashmiri import find
from kashmiri.database import data
